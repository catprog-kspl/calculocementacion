
package Modelo;


public class Datos {

    /**
     * @return the V1
     */
    public float getV1() {
        return V1;
    }

    /**
     * @param V1 the V1 to set
     */
    public void setV1(float V1) {
        this.V1 = V1;
    }

    /**
     * @return the V2
     */
    public float getV2() {
        return V2;
    }

    /**
     * @param V2 the V2 to set
     */
    public void setV2(float V2) {
        this.V2 = V2;
    }

    /**
     * @return the V3
     */
    public float getV3() {
        return V3;
    }

    /**
     * @param V3 the V3 to set
     */
    public void setV3(float V3) {
        this.V3 = V3;
    }

    /**
     * @return the V4
     */
    public float getV4() {
        return V4;
    }

    /**
     * @param V4 the V4 to set
     */
    public void setV4(float V4) {
        this.V4 = V4;
    }

    /**
     * @return the V5
     */
    public float getV5() {
        return V5;
    }

    /**
     * @param V5 the V5 to set
     */
    public void setV5(float V5) {
        this.V5 = V5;
    }

    /**
     * @return the VT
     */
    public float getVT() {
        return VT;
    }

    /**
     * @param VT the VT to set
     */
    public void setVT(float VT) {
        this.VT = VT;
    }

    /**
     * @return the exc
     */
    public float getExc() {
        return exc;
    }

    /**
     * @param exc the exc to set
     */
    public void setExc(float exc) {
        this.exc = exc;
    }

    /**
     * @return the diametroBarrena
     */
    public float getDiametroBarrena() {
        return diametroBarrena;
    }

    /**
     * @param diametroBarrena the diametroBarrena to set
     */
    public void setDiametroBarrena(float diametroBarrena) {
        this.diametroBarrena = diametroBarrena;
    }

    /**
     * @return the diametroExterno
     */
    public float getDiametroExterno() {
        return diametroExterno;
    }

    /**
     * @param diametroExterno the diametroExterno to set
     */
    public void setDiametroExterno(float diametroExterno) {
        this.diametroExterno = diametroExterno;
    }

    /**
     * @return the diametroInt
     */
    public float getDiametroInt() {
        return diametroInt;
    }

    /**
     * @param diametroInt the diametroInt to set
     */
    public void setDiametroInt(float diametroInt) {
        this.diametroInt = diametroInt;
    }

    /**
     * @return the alturaTapon
     */
    public float getAlturaTapon() {
        return alturaTapon;
    }

    /**
     * @param alturaTapon the alturaTapon to set
     */
    public void setAlturaTapon(float alturaTapon) {
        this.alturaTapon = alturaTapon;
    }

    /**
     * @return the alturaFondo
     */
    public float getAlturaFondo() {
        return alturaFondo;
    }

    /**
     * @param alturaFondo the alturaFondo to set
     */
    public void setAlturaFondo(float alturaFondo) {
        this.alturaFondo = alturaFondo;
    }

    /**
     * @return the asentamiento
     */
    public float getAsentamiento() {
        return asentamiento;
    }

    /**
     * @param asentamiento the asentamiento to set
     */
    public void setAsentamiento(float asentamiento) {
        this.asentamiento = asentamiento;
    }

private float diametroBarrena; 
private float diametroExterno; 
private float diametroInt; 
private float alturaTapon; 
private float alturaFondo; 
private float asentamiento;
     



private float V1;
private float V2;
private float V3;
private float V4;
private float V5;
private float VT;
private float exc;
    
}
